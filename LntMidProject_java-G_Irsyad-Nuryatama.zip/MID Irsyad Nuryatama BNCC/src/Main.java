import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class Main {
	Vector<krywn>  karyawan2= new Vector<>(); 
	
	void list() {
		for(int a = 0; a < karyawan2.size();a ++) {
			System.out.println((1 + a));
			System.out.println((karyawan2.get(a).nama));
			System.out.println((karyawan2.get(a).jenis));
			System.out.println((karyawan2.get(a).jabatan));
			System.out.println((karyawan2.get(a).ID));
			System.out.println((karyawan2.get(a).price));
	}
	}
	
	void sorting () {
		krywn c;
		for (int a = 0; a <karyawan2.size(); a++ ) {
			for (int j = 0; j< karyawan2.size(); j++) {
				if(karyawan2.get(a).nama.compareTo(karyawan2.get(j).nama) < 0) {
					c = karyawan2.get(j);
					karyawan2.set(j, karyawan2.get(a));
					karyawan2.set(a,c);
				}
				}
		}
	}
				
	
	public Main() {
		
		Scanner sc = new Scanner(System.in);
		int insert = 0;
		System.out.println("PT Musang");
		System.out.println("=============");
		do {
			System.out.println("1. Insert data karyawan ");
			System.out.println("2. View data karyawan ");
			System.out.println("3. Update data karyawan ");
			System.out.println("4. Delete data karyawan ");
			System.out.println("5. Exit ");
			System.out.println("Pilih >> ");
			insert = sc.nextInt();
			sc.nextLine();
			
			
			
			if(insert == 1) {
				
				String nama,jenis,jabatan;
				do {
					System.out.println("Input nama karyawan [>= 3] :");
					nama = sc.nextLine();
				}while (nama.length() <= 3 );
				do {
					System.out.println("Input jenis kelamin [Laki-laki | Perempuan] :");
					jenis = sc.nextLine();
				}while(!(jenis.equals("Laki-laki") || jenis.equals("Perempuan")));
				do {
					System.out.println("Input jabatan [Manager |Supervisor | Admin] :");
					jabatan = sc.nextLine();
				}while(!(jabatan.equals("Manager") || jabatan.equals("Supervisor") || jabatan.equals("Admin")));
				
				
				int price = 0;
				if (jabatan.equals("Manager")) {
					price += 8000000;
				} else if (jabatan.equals("Supervisor")) {
					price += 6000000;
				} else if (jabatan.equals("Admin")) {
					price += 4000000;	
					
				
			
			
				Random random = new Random();
				String randomCharacter = "QWERTYUIOPASDFGHJKLZXCVBNM";
				String ID="";
				
				
				for(int  a = 0; a < 2; a++) {
					ID +=  randomCharacter.charAt(	
					Math.abs(random.nextInt() % randomCharacter.length()));
					}
				
				for (int a = 0; a <4; a++) {
					ID +=  Math.abs(random.nextInt() % 8);
				}
				
				
				
				krywn a = new krywn();
				a.nama = nama;
				a.jenis = jenis;
				a.jabatan = jabatan;
				a.ID = ID;
				a.price = price;
				karyawan2.add (a);
				
			}
			
			}
				else if (insert == 2 ) {
				list();
				sorting ();
				
				}
				
			
				else if (insert == 3) {
				list();
				sorting ();
				
				int no;
				do {
					System.out.println("Input nomor urutan karyawan yang ingin diupdate :" + karyawan2.size());
					no = sc.nextInt();
				}while(no < 0);
				
				String nama,jenis,jabatan;
				do {
					System.out.println("Input nama karyawan [>= 3] :");
					nama = sc.nextLine();
				}while (nama.length() <= 3);
				do {
					System.out.println("Input jenis kelamin [Laki-laki | Perempuan] :");
					jenis = sc.nextLine();
				}while(!(jenis.equals("Laki-laki") || jenis.equals("Perempuan")));
				do {
					System.out.println("Input jabatan [Manager |Supervisor | Admin] :");
					jabatan = sc.nextLine();
				}while(!(jabatan.equals("Manager") || jabatan.equals("Supervisor") || jabatan.equals("Admin")));
				
//				System.out.println("Berhasil mengupdate karyawan dengan id " + karyawan2ID);
				
					
				}
			
				else if (insert == 4) {
				list();
				sorting();
				
				int choosedelete = 0;
				
				do {
					System.out.println("delete karyawan [1.. "+ karyawan2.size());
					choosedelete = sc.nextInt();
					sc.nextLine();
				}while(choosedelete <0 || choosedelete > karyawan2.size());
				
			
		}
				
			
			
			
		}while (insert != 5);
		System.out.println("Terima kasih");
		
	}

	public static void main(String[] args) {
		new Main();

	}

}
