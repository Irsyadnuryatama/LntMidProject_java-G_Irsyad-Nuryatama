
public class krywn {
String nama;
String jenis;
String jabatan;
String ID;
Integer price;	
	public krywn() {
		// TODO Auto-generated constructor stub
	}

}
